package com.microsoft.appcenter.sasquatch.activities;

import android.annotation.SuppressLint;
import android.app.Activity;

public class CrashSubActivity2 extends Activity {

    @Override
    @SuppressLint("MissingSuperCall")
    public void onResume() {

    }
}
