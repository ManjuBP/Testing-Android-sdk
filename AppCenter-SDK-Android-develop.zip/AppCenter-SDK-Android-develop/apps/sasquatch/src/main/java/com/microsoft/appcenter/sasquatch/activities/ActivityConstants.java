package com.microsoft.appcenter.sasquatch.activities;

final class ActivityConstants {

    final static String EXTRA_TARGET_SELECTED = "TARGET_SELECTED";
}
