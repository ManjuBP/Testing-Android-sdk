package com.microsoft.appcenter;

public class AppCenterPrivateHelper {

    public static void unsetInstance() {
        AppCenter.unsetInstance();
    }
}
