package com.microsoft.appcenter.distribute;

import org.junit.Test;

public class DistributeUtilsTest {

    @Test
    public void init() {
        new DistributeUtils();
        new DistributeConstants();
    }
}
