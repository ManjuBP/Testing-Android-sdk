package com.microsoft.appcenter.utils;

public class PrefStorageConstants {
    public static final String KEY_INSTALL_ID = "installId";
    public static final String KEY_ENABLED = "enabled";
}
