package com.microsoft.appcenter.http;

public interface ServiceCall {

    /**
     * Cancel the call if possible.
     */
    void cancel();
}
