package com.microsoft.appcenter.utils;

import org.junit.Test;

public class InstrumentationRegistryHelperTest {

    @Test
    public void instrumentationRegistryHelperCoverage() {
        new InstrumentationRegistryHelper();
    }
}