package com.microsoft.appcenter.rum;

import org.junit.Test;

public class RealUserMeasurementsAndroidTest {

    @Test
    public void test() {
        // TODO
    }
}