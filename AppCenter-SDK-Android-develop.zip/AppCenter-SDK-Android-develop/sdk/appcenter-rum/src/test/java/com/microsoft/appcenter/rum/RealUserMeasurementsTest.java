package com.microsoft.appcenter.rum;

import org.junit.Test;

public class RealUserMeasurementsTest {

    @Test
    public void test() {
        // TODO
    }
}